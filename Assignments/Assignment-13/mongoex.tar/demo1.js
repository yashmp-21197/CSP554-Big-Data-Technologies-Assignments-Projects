db.unicorns.insert(
{name: 'Leto',
gender: 'm',
home: 'Arrakeen',
worm: false}
)
