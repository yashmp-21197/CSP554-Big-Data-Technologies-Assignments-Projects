db.unicorns.update({name: 'Roooooodles'},
{$set: {weight: 590}})

