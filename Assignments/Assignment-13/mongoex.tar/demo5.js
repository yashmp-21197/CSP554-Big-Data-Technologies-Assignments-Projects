db.unicorns.update({name: 'Roooooodles'},
{weight: 590})

